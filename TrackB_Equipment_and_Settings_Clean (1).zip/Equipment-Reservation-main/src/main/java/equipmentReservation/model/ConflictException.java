package equipmentReservation.model;
/** Indicates that the requested action conflicts with existing data (FR-21). */
public class ConflictException extends Exception {
    private static final long serialVersionUID = 1L;
    /** @param message user-facing explanation */
    public ConflictException(String message) { super(message); }
}
