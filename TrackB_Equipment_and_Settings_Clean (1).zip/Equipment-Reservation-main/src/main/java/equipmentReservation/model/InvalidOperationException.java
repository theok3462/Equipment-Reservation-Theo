package equipmentReservation.model;
/** Indicates an operation is prohibited by the item's current state (FR-23). */
public class InvalidOperationException extends Exception {
    private static final long serialVersionUID = 1L;
    /** @param message user-facing explanation */
    public InvalidOperationException(String message) { super(message); }
}
