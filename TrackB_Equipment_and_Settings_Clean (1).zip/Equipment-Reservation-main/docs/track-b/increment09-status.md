# Track B Increment 09 — implementation status

Owner: Theo. Source: `prompts/09_equipment_admin.md`.

## Implemented now
- `EquipmentService`: admin-only add/update and return-to-service; signed-in reads; categories; EQUIPMENT change event.
- `EquipmentAdminStore`: persistence contract for later SQLite integration.
- `ConflictException`, `InvalidOperationException`; field-aware `ValidationException` constructor.
- `EquipmentServiceTest`: six JUnit tests using a fake store to test FR-20 through FR-23.

## Still required before increment 09 is complete
- Implement SQLite adapter against increment 08's schema/transactions/repositories.
- Enforce unique ID in the DB, and row-based atomic updates.
- In ONE transaction, verify no open maintenance, transition state, and insert service_log with admin + timestamp.
- Verify DB CHECK constraints, existing reservation records unaffected by update, rollback behavior and audit log in SQLite integration tests.
- Wire service to real login session (currently accepts a `Supplier<User>`).
- Run `./gradlew build` with JUnit dependencies present and reconcile any newer main changes.

## Code integration
Production files are designed to be added to `src/main/java/`; do not put test FakeStore into production.
Record the actual AI conversation/prompts used to generate this code per the course requirement.
