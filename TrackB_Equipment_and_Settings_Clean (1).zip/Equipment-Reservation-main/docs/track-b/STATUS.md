# Track B development status

## Implemented in this package

- Increment 09: EquipmentService and EquipmentAdminStore interface, with unit tests using a simple in-memory store.
- Increment 10: SettingsService and SettingsStore interface, with unit tests using an in-memory store.

## Remaining integration work

- Increment 09: Connect EquipmentAdminStore to the team's SQLite database and check the service log and history in database tests.
- Increment 10: Connect SettingsStore to the settings table and test persistence after closing and reopening the database.
- Increment 16: Checkout, return and overdue service (requires reservation, expiration and persistence features).
- Increment 17: Maintenance service (requires checkout and persistence).
- Increment 18: Persistence and rollback tests (requires services and database schema).
- Increments 22-24: Admin Swing windows and controllers; test against the integrated services.
- Run `./gradlew test`, `./gradlew build`, and the full macOS/Windows acceptance tests after integration.

The in-memory test stores are for unit testing only. They do not replace SQLite storage.
