# Track B — Increment 09: Equipment Administration Acceptance Cases

Owner: Theo · Requirements: FR-03, FR-20–FR-23

These are planned acceptance cases. **Not executed**. They should be backed by JUnit `EquipmentServiceTest` once increments 05–08 (database, repositories, and session authorization) are available.

| ID | Requirement | Setup / action | Expected result |
| --- | --- | --- | --- |
| B09-01 | FR-20 | Sign in as an administrator; add equipment with a new ID, name and category | Equipment is saved and appears in the catalog; EQUIPMENT model event is fired |
| B09-02 | FR-20 | Sign in as a borrower; try adding or modifying equipment | AuthorizationException; no database modification |
| B09-03 | FR-21 | Add equipment using an existing ID | ConflictException identifies duplicate ID; existing item unchanged |
| B09-04 | FR-21 | Try empty or whitespace-only equipment ID, name, or category | Field-specific ValidationException; no database modification |
| B09-05 | FR-21 | Add equipment with leading/trailing whitespace in ID, name, category | Stored values are trimmed |
| B09-06 | FR-22 | Edit an item's name/category/description/condition/status using the same ID | Only allowed equipment fields change; ID stays unchanged |
| B09-07 | FR-22 | Update an ID not in the database | NotFoundException; no item inserted |
| B09-08 | FR-22 | Create a reservation referencing an item, then update the item | Reservation and reservation history remain intact |
| B09-09 | FR-23 | Mark an item NON_OPERATIONAL, sign in as an admin, return it to service with GOOD condition and no open maintenance | Item becomes OPERATIONAL; service_log row stores equipment ID, admin and timestamp in the same transaction |
| B09-10 | FR-23 | Try returning an already OPERATIONAL item | InvalidOperationException; no service_log entry |
| B09-11 | FR-23 | Try returning a NON_OPERATIONAL item with DAMAGED condition | Field-specific ValidationException; no status change or log entry |
| B09-12 | FR-23 | Try returning an item with an open maintenance record | InvalidOperationException; status and maintenance record unchanged |
| B09-13 | FR-23 | Make service_log insertion fail during return-to-service transaction | Entire transaction rolls back; item remains NON_OPERATIONAL |
| B09-14 | FR-03 | Sign in; list equipment and categories | Signed-in user can read catalog and category choices |
| B09-15 | FR-20 | Sign out; try equipment reads/writes | AuthorizationException; no unauthorized access |

## Implementation prerequisites

The uploaded snapshot includes the MVC/model skeleton from PR #1 but **does not yet include** `Database`, `EquipmentRepository`, `Session`, `ReservationSystem`, the service facade, or shared `TestSystem`. Increment 09 should be implemented on top of completed increments 05–08, not with duplicate temporary versions of those shared classes.

## Evidence to capture after implementation

- Passing `EquipmentServiceTest` output and `./gradlew build` output.
- GUI screenshots for add/edit/duplicate validation and return-to-service once Increment 22 is implemented.
- Verify service_log timestamp/admin and preserved reservation rows using a test query.
- Save verbatim AI prompts used for implementation in `prompts/` in accordance with the group rules.
